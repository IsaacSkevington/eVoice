This all the source code for the Eve program
To build the python file to an executable, run Build.bat (assumes python and pip installed and on path)
The EveDBMigration file can be run after build (or before assuming dependancies pyodbc and mysql.connector)
Change the details at the top of the program to specify the server to pull from and push to
Good luck, any questions or bugs to y14isske@latymer.co.uk or y14jadob@latymer.co.uk